package com.iris.dao;

import com.iris.models.Employee;

public interface EmployeeDao {
	public boolean registerEmployee(Employee e) throws Exception;
	public boolean validateEmployee(String name,String password)throws Exception;

}
