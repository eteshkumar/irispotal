package com.iris.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.iris.dao.EmployeeDao;
import com.iris.daoimpl.EmployeeDaoImpl;
import com.iris.models.Employee;

@WebServlet("/LoginValidate")
public class LoginValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public LoginValidate() {
        super();
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request,response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	EmployeeDao obj=new EmployeeDaoImpl();
	 String s1=request.getParameter("name");
	 String s2=request.getParameter("password");
	 
	 Employee e1=new Employee();
	 boolean b=false;
	 try{
		 b=obj.validateEmployee(s1, s2);
	 }
	 catch(Exception e){
		 e.printStackTrace();
	 }
	 if(b==true){
		HttpSession session=request.getSession();
		session.setAttribute("empobj", e1);
		RequestDispatcher rd=request.getRequestDispatcher("ValidServlet");
		rd.forward(request, response);
	 }
		 else{
			 out.println("Invalid Credentials!!");
		 }
		 
	 }
	
	}


