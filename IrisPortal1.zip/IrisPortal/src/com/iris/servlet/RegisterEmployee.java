package com.iris.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.dao.EmployeeDao;
import com.iris.daoimpl.EmployeeDaoImpl;
import com.iris.models.Employee;

@WebServlet("/RegisterEmployee")
public class RegisterEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterEmployee() {
        super();
    }
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		EmployeeDao es=new EmployeeDaoImpl();
		String s1=request.getParameter("id");
		int i=Integer.parseInt(s1);
		String s2=request.getParameter("name");
		String s3=request.getParameter("gender");
		String s4=request.getParameter("email");
		String s5=request.getParameter("pwd");
		String s6=request.getParameter("city");
		Employee e=new Employee();
		e.setEmployeeId(i);
		e.setEmployeeName(s2);
		e.setGender(s3);
		e.setEmailAddress(s4);
		e.setPassword(s5);
		e.setCity(s6);
		
		boolean b=false;
		try{
			b=es.registerEmployee(e);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		if(b==true){
		
		out.println("Register sucessfully!!");  
		}
		else{
			out.println("Registeration Failed!!");  
		}
		
		
	
		
		
		
		
			}

}
