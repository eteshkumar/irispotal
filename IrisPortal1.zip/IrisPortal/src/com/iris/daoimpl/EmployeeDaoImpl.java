package com.iris.daoimpl;
import com.iris.utility.ConnectionProvider;
import com.iris.dao.EmployeeDao;
import java.sql.PreparedStatement;
import java.sql.*;
import com.iris.models.Employee;


public class EmployeeDaoImpl implements EmployeeDao  {
	Connection Conn=ConnectionProvider.getConn();
	public boolean registerEmployee(Employee e) throws Exception{
		
		PreparedStatement ps=Conn.prepareStatement("insert into  Employeetab values(?,?,?,?,?,?)");
		ps.setInt(1, e.getEmployeeId());
		ps.setString(2, e.getEmployeeName());
		ps.setString(3, e.getGender());
		ps.setString(4, e.getEmailAddress());
		ps.setString(5, e.getPassword());
		ps.setString(6, e.getCity());
		int i=ps.executeUpdate();
		if(i!=0){
			return true;
		}
		else{
			return false;
		}
	}
	public boolean validateEmployee(String name,String password)throws Exception{
 PreparedStatement ps=Conn.prepareStatement("select * from Employeetab where EmployeeName=? and password=?");
	ps.setString(1, name);
	ps.setString(2, password);
	ResultSet rs=ps.executeQuery();
	if(rs.next()){
		return true;
		
	}
	else return false;
	
	}

}
